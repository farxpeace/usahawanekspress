Readme.txt
==========

I wanted to do something good for the community by putting this up on GitHub.  The code is several years old, first published in 2004 by jpmaster77.  This code has been particularly useful to me and many others as referenced by the 44 pages of comments this script has now and is still receiving two or three comments per day (5 years later!).

Hopefully people will view this as useful. My goal is to try to develop this free resource by updating the code and adding useful features.

I've published a couple articles referencing this code on my blog: http://www.ivannovak.com.  One comparing it to a for-pay script I found on ThemeForest (http://www.themeforest.net) and another demonstrating how easy it is to set up and run (http://www.ivannovak.com/jpmaster77s-login-system-tutorial).

I will answer any questions you all may have to the best of my ability.

Thanks,

-Ivan

UPDATE: All further updates will be noted in changes.txt