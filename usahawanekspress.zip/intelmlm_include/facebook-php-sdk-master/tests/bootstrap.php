<?php

$base = realpath(dirname(__FILE__) . '/..');
require "$base/src/base_facebook.php";
require "$base/src/facebook.php";
