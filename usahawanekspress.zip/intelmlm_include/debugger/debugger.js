$(function(){
    $('<div>ss</div>').dialog();
})