<?php
Class MetroUi_Grid {
    
    var $span = '4';
    
    function MetroUi_Grid($span, $isFluid = true){
        
        $this->span = $span;
    }
    
    
    
    
    
    
}

?>