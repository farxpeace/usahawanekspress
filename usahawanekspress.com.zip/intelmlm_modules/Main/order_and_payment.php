<div class="grid" style="margin-bottom: 0px;">
    <div class="row">
        <div class="span12">
            
        </div>
    </div>
</div>

