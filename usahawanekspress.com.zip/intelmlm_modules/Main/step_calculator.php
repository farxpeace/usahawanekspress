
<div class="grid fluid" id="calculator_fb">
    <div class="row">
        <div class="span8">
            Anda mempunyai <span id="_fbc_total_friend"></span> orang rakan Facebook dan anda memilih Pakej <span id="_fbc_pakej"></span> E-Book.<br />
            Maka anda mempunyai <span id="_fbc_level"></span> kumpulan promosi.<br />
            <div>
                <div class="padding5 fg-white bg-amber">Andaikan Kumpulan Promosi 1 mempunyai</div>
                <div class="input-control text size2">
                    <input type="text" />
                </div> orang pembeli
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

</script>