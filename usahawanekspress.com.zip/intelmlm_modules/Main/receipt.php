<style>
table.resit tbody tr td:first-child {
    width: 100px !important;
    
}
</style>
<div class="" style="padding: 5px; border: 1px solid #FFCCCC; width: 500px;">
    <div class="padding5 bg-amber fg-white text-center ">
                Resit Pembayaran
            </div>
    <table style="width: 100%;" class="resit">
        <tr>
            <td class="right">Receipt no :</td>
            <td>#332332454</td>
        </tr>
        <tr>
            <td class="right">Terima dari :</td>
            <td>Rizuan rais</td>
        </tr>
        <tr>
            <td class="right">Amaun :</td>
            <td>RM 10</td>
        </tr>
        
    </table>
    
</div>
    </div>
</div>

